# EMNISTLettersKmeans
This project implements a sequential k-means python script to do EMNIST handwritten letters classification
